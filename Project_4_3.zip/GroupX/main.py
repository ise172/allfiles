from Classes.World import World




myWorld = World()

print myWorld.Edges 

print myWorld.Verticies


myWorld.runSimulation(10)




